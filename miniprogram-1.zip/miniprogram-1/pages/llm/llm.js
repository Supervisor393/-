Page({
  data: {
    messages: [],
    userInput: '',
    fileName: '', // 上传的文件名
    filePath: '', // 文件路径
  },

  // 输入框内容变化
  onInputChange(e) {
    this.setData({
      userInput: e.detail.value,
    });
  },

  // 发送用户消息
  submitRequest() {
    const { userInput, messages } = this.data;

    if (userInput.trim() === '') {
      wx.showToast({ title: '请输入问题', icon: 'none' });
      return;
    }

    // 添加用户消息
    this.setData({
      messages: [...messages, { sender: 'user', text: userInput }],
      userInput: '', // 清空输入框
    });

    // 调用后端接口（假设是调用大模型API）
    this.callLLM(userInput);
  },

  // 调用大模型接口
  callLLM(input) {
    // 在这里发送用户输入到后端的大模型进行处理
    wx.showToast({ title: '请求处理中...', icon: 'loading' });

    // 假设请求成功后返回模型生成的消息
    setTimeout(() => {
      const newMessage = {
        sender: 'llm',
        text: '这是大模型的响应：' + input, // 模拟大模型的返回
      };
      this.setData({
        messages: [...this.data.messages, newMessage],
      });
    }, 1000);
  },

  // 选择文件并上传
  chooseFile() {
    wx.chooseMessageFile({
      count: 1, // 只能选择一个文件
      type: 'file', // 选择文件
      success: (res) => {
        const filePath = res.tempFiles[0].path; // 获取文件路径
        const fileName = res.tempFiles[0].name; // 获取文件名

        // 设置文件名和文件路径
        this.setData({
          fileName: fileName,
          filePath: filePath,
        });

        // 这里可以调用上传接口，传递文件到服务器进行处理
        this.uploadFile(filePath);
      },
    });
  },

  // 上传文件到服务器
  uploadFile(filePath) {
    wx.uploadFile({
      url: 'https://example.com/upload', // 上传服务器的URL
      filePath: filePath,
      name: 'file',
      success(res) {
        if (res.statusCode === 200) {
          wx.showToast({ title: '文件上传成功', icon: 'success' });
        } else {
          wx.showToast({ title: '文件上传失败', icon: 'none' });
        }
      },
      fail() {
        wx.showToast({ title: '上传失败', icon: 'none' });
      }
    });
  },
});
