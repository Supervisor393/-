Page({
  data: {},

  // 跳转到 llm 页面
  navigateToLLM() {
    wx.navigateTo({
      url: '/pages/llm/llm', // 页面路径
    });
  },
});
