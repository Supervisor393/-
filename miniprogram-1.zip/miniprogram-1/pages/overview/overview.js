Page({
  data: {
    title: "项目概述",
    description: "本小程序旨在为用户提供便捷的民事二审诉讼监督模型。",
  },
})
