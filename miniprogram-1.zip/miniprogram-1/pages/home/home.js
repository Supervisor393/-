Page({
  data: {
    title: "欢迎来到首页",
  },

  // 跳转到项目概述页面
  navigateToOverview() {
    wx.navigateTo({
      url: '/pages/overview/overview',
    })
  },

  // 跳转到功能介绍页面
  navigateToFeatures() {
    wx.navigateTo({
      url: '/pages/features/features',
    })
  },

  // 跳转到开始使用页面
  navigateToStart() {
    wx.navigateTo({
      url: '/pages/start/start',
    })
  },
})
